import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../constants/app_constants.dart';

class OtpService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// Generate a cryptographically random N-digit OTP
  String generateOtp([int length = AppStrings.otpLength]) {
    final random = Random.secure();
    return List.generate(length, (_) => random.nextInt(10)).join();
  }

  /// Store a pending OTP in Firestore for verification
  Future<String> createAndStoreOtp(String userId) async {
    final otp = generateOtp();
    final expiresAt = DateTime.now()
        .add(const Duration(seconds: AppStrings.otpExpirySeconds));

    await _db.collection('pendingOtp').doc(userId).set({
      'otp': otp,
      'userId': userId,
      'createdAt': FieldValue.serverTimestamp(),
      'expiresAt': expiresAt.toIso8601String(),
    });

    return otp;
  }

  /// Verify the OTP entered by the user
  Future<bool> verifyOtp(String userId, String enteredOtp) async {
    final doc = await _db.collection('pendingOtp').doc(userId).get();

    if (!doc.exists) return false;

    final data = doc.data()!;
    final storedOtp = data['otp'] as String;
    final expiresAt = DateTime.parse(data['expiresAt'] as String);

    // Check expiry
    if (DateTime.now().isAfter(expiresAt)) {
      await doc.reference.delete(); // clean up expired OTP
      return false;
    }

    // Check match
    if (storedOtp == enteredOtp) {
      await doc.reference.delete(); // clean up used OTP
      return true;
    }

    return false;
  }

  /// Delete any pending OTP for a user (e.g. on cancel)
  Future<void> clearPendingOtp(String userId) async {
    await _db.collection('pendingOtp').doc(userId).delete();
  }
}
