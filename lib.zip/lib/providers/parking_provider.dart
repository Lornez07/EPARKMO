import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/parking_slot.dart';
import '../models/reservation.dart';
import '../models/parking_log.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';
import '../services/parking_service.dart';
import '../constants/app_constants.dart';

class ParkingProvider extends ChangeNotifier {
  final AuthService _auth = AuthService();
  final ParkingService _service = ParkingService();

  // ─── State ────────────────────────────────────────────────────────────────
  UserModel? _currentUser;
  List<ParkingSlot> _slots = [];
  List<ParkingLog> _logs = [];
  Reservation? _activeReservation;
  bool _barrierOpen = false;
  bool _isLoading = false;
  String? _error;

  StreamSubscription? _slotsSub;
  StreamSubscription? _logsSub;
  StreamSubscription? _resSub;
  Timer? _barrierTimer;

  // ─── Getters ──────────────────────────────────────────────────────────────
  UserModel? get currentUser => _currentUser;
  List<ParkingSlot> get slots => _slots;
  List<ParkingLog> get logs => _logs;
  Reservation? get activeReservation => _activeReservation;
  bool get barrierOpen => _barrierOpen;
  bool get isLoading => _isLoading;
  String? get error => _error;

  int get availableCount => _slots.where((s) => s.isAvailable).length;
  int get reservedCount => _slots.where((s) => s.isReserved).length;
  int get occupiedCount => _slots.where((s) => s.isOccupied).length;

  bool get hasActiveReservation => _activeReservation != null;

  void clearError() {
    _error = null;
    notifyListeners();
  }

  // ─── Auth ─────────────────────────────────────────────────────────────────
  Future<bool> signIn(String email, String password) async {
    _setLoading(true);
    try {
      final user = await _auth.signIn(email, password);
      _currentUser = user;
      _initFirebaseListeners();
      return true;
    } catch (e) {
      _error = e.toString().replaceFirst('Exception: ', '');
      notifyListeners();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> register({
    required String email,
    required String password,
    required String name,
  }) async {
    _setLoading(true);
    try {
      final user = await _auth.register(email: email, password: password, name: name);
      _currentUser = user;
      _initFirebaseListeners();
      return true;
    } catch (e) {
      _error = e.toString().replaceFirst('Exception: ', '');
      notifyListeners();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<void> signOut() async {
    await _disposeListeners();
    await _auth.signOut();
    _currentUser = null;
    _slots = [];
    _logs = [];
    _activeReservation = null;
    notifyListeners();
  }

  // ─── Firebase Listeners ───────────────────────────────────────────────────
  void _initFirebaseListeners() {
    _disposeListeners();
    if (_currentUser == null) return;

    // Slots
    _slotsSub = _service.getSlotsStream().listen((data) {
      _slots = data;
      // If active reservation slot is now occupied by sensor, we might need to complete it
      // But we'll let the user manually confirm arrival or rely on Firestore logic
      notifyListeners();
    });

    // Logs
    _logsSub = _service.getLogsStream().listen((data) {
      _logs = data;
      notifyListeners();
    });

    // Active Reservation for this user
    _resSub = FirebaseFirestore.instance
        .collection('reservations')
        .doc('${_currentUser!.uid}_active')
        .snapshots()
        .listen((doc) {
      if (doc.exists) {
        final data = doc.data()!;
        _activeReservation = Reservation(
          id: doc.id,
          slotId: data['slotId'],
          slotNumber: data['slotNumber'],
          userId: data['userId'],
          userName: data['userName'],
          startTime: (data['startTime'] as Timestamp).toDate(),
          expiresAt: DateTime.parse(data['expiresAt']),
          status: ReservationStatus.active,
        );
      } else {
        _activeReservation = null;
      }
      notifyListeners();
    });
  }

  Future<void> _disposeListeners() async {
    await _slotsSub?.cancel();
    await _logsSub?.cancel();
    await _resSub?.cancel();
    _barrierTimer?.cancel();
  }

  // ─── Actions ──────────────────────────────────────────────────────────────
  Future<String?> reserveSlot(ParkingSlot slot) async {
    if (_currentUser == null) return 'Not logged in.';
    _setLoading(true);
    try {
      await _service.reserve(slot: slot, user: _currentUser!);
      return null;
    } catch (e) {
      return e.toString();
    } finally {
      _setLoading(false);
    }
  }

  Future<void> cancelReservation() async {
    if (_activeReservation == null || _currentUser == null) return;
    _setLoading(true);
    try {
      await _service.cancel(
        slotId: _activeReservation!.slotId,
        slotNumber: _activeReservation!.slotNumber,
        user: _currentUser!,
      );
    } catch (e) {
      _error = e.toString();
    } finally {
      _setLoading(false);
    }
  }

  Future<void> confirmArrival() async {
    if (_activeReservation == null || _currentUser == null) return;
    _setLoading(true);
    try {
      await _service.confirmArrival(
        slotId: _activeReservation!.slotId,
        slotNumber: _activeReservation!.slotNumber,
        user: _currentUser!,
      );
    } catch (e) {
      _error = e.toString();
    } finally {
      _setLoading(false);
    }
  }

  void openBarrier() async {
    if (_currentUser == null) return;
    _barrierOpen = true;
    notifyListeners();

    await _service.logBarrier(_currentUser!, true);

    _barrierTimer?.cancel();
    _barrierTimer = Timer(const Duration(seconds: AppStrings.barrierAutoCloseSeconds), () async {
      _barrierOpen = false;
      notifyListeners();
      await _service.logBarrier(_currentUser!, false);
    });
  }

  void _setLoading(bool v) {
    _isLoading = v;
    notifyListeners();
  }

  @override
  void dispose() {
    _disposeListeners();
    super.dispose();
  }
}
