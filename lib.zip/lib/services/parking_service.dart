import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../models/parking_slot.dart';
import '../models/reservation.dart';
import '../models/parking_log.dart';
import '../models/user_model.dart';
import '../constants/app_constants.dart';

class ParkingService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final _uuid = const Uuid();

  // ─── Streams ──────────────────────────────────────────────────────────────
  Stream<List<ParkingSlot>> getSlotsStream() {
    return _db.collection('parkingSlots').orderBy('slotNumber').snapshots().map(
          (snapshot) => snapshot.docs
              .map((doc) => ParkingSlot.fromMap({...doc.data(), 'id': doc.id}))
              .toList(),
        );
  }

  Stream<List<ParkingLog>> getLogsStream() {
    return _db
        .collection('parkingLogs')
        .orderBy('timestamp', descending: true)
        .limit(50)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => ParkingLog.fromMap({...doc.data(), 'id': doc.id}))
              .toList(),
        );
  }

  // ─── Actions ──────────────────────────────────────────────────────────────
  Future<void> reserve({
    required ParkingSlot slot,
    required UserModel user,
  }) async {
    final now = DateTime.now();
    final expiresAt = now.add(const Duration(minutes: AppStrings.reservationMinutes));

    final batch = _db.batch();

    // Update slot
    batch.update(_db.collection('parkingSlots').doc(slot.id), {
      'status': SlotStatus.reserved.name,
      'userId': user.uid,
      'reservedByName': user.name,
    });

    // Create log
    final logId = _uuid.v4();
    batch.set(_db.collection('parkingLogs').doc(logId), {
      'action': 'Slot ${slot.slotNumber} reserved by ${user.name}',
      'slotId': slot.id,
      'slotNumber': slot.slotNumber,
      'userId': user.uid,
      'userName': user.name,
      'timestamp': FieldValue.serverTimestamp(),
      'type': 'reservation',
    });

    // We can also store the active reservation in a user subcollection or meta collection
    // For simplicity with the existing models, we'll let the provider handle the active reservation state
    // But we might want a 'reservations' collection
    batch.set(_db.collection('reservations').doc('${user.uid}_active'), {
      'slotId': slot.id,
      'slotNumber': slot.slotNumber,
      'userId': user.uid,
      'userName': user.name,
      'startTime': FieldValue.serverTimestamp(),
      'expiresAt': expiresAt.toIso8601String(),
      'status': 'active',
    });

    await batch.commit();
  }

  Future<void> cancel({
    required String slotId,
    required int slotNumber,
    required UserModel user,
  }) async {
    final batch = _db.batch();

    batch.update(_db.collection('parkingSlots').doc(slotId), {
      'status': SlotStatus.available.name,
      'userId': null,
      'reservedByName': null,
    });

    batch.delete(_db.collection('reservations').doc('${user.uid}_active'));

    batch.set(_db.collection('parkingLogs').doc(_uuid.v4()), {
      'action': 'Slot $slotNumber reservation cancelled by ${user.name}',
      'slotId': slotId,
      'slotNumber': slotNumber,
      'userId': user.uid,
      'userName': user.name,
      'timestamp': FieldValue.serverTimestamp(),
      'type': 'cancellation',
    });

    await batch.commit();
  }

  Future<void> confirmArrival({
    required String slotId,
    required int slotNumber,
    required UserModel user,
  }) async {
    final batch = _db.batch();

    batch.update(_db.collection('parkingSlots').doc(slotId), {
      'status': SlotStatus.occupied.name,
      'isSensorActive': true,
      'distanceCm': 10.0, // Mocking arrival
    });

    batch.delete(_db.collection('reservations').doc('${user.uid}_active'));

    batch.set(_db.collection('parkingLogs').doc(_uuid.v4()), {
      'action': 'Slot $slotNumber: ${user.name} arrived',
      'slotId': slotId,
      'slotNumber': slotNumber,
      'userId': user.uid,
      'userName': user.name,
      'timestamp': FieldValue.serverTimestamp(),
      'type': 'arrival',
    });

    await batch.commit();
  }

  Future<void> logBarrier(UserModel user, bool opened) async {
    await _db.collection('parkingLogs').add({
      'action': 'Barrier ${opened ? "opened" : "closed"} by ${user.name}',
      'slotId': '',
      'slotNumber': 0,
      'userId': user.uid,
      'userName': user.name,
      'timestamp': FieldValue.serverTimestamp(),
      'type': 'barrier',
    });
  }

  // ─── Initial Seed (Run once or manually in console) ──────────────────────
  Future<void> seedInitialData() async {
    final slots = _db.collection('parkingSlots');
    for (int i = 1; i <= 6; i++) {
      await slots.doc('slot-$i').set({
        'slotNumber': i,
        'status': 'available',
        'isSensorActive': false,
        'distanceCm': null,
        'userId': null,
        'reservedByName': null,
      });
    }
  }
}
