import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../models/parking_slot.dart';
import '../providers/parking_provider.dart';
import '../widgets/slot_card.dart';

class ReserveTab extends StatelessWidget {
  const ReserveTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ParkingProvider>(
      builder: (context, provider, _) {
        return SafeArea(
          bottom: false,
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Reserve a Slot',
                              style: AppTextStyles.displayMedium)
                          .animate()
                          .fadeIn(duration: 400.ms),
                      const SizedBox(height: 6),
                      Text('Pick an available slot below',
                              style: AppTextStyles.bodyMedium)
                          .animate(delay: 80.ms)
                          .fadeIn(duration: 400.ms),
                      const SizedBox(height: 24),

                      // Active reservation card
                      if (provider.hasActiveReservation)
                        _ActiveReservationCard(provider: provider)
                            .animate()
                            .fadeIn(duration: 400.ms)
                            .slideY(begin: -0.1),

                      if (provider.hasActiveReservation)
                        const SizedBox(height: 24),

                      if (!provider.hasActiveReservation)
                        Text('Available Slots',
                                style: AppTextStyles.headingMedium)
                            .animate(delay: 150.ms)
                            .fadeIn(duration: 400.ms),
                      if (!provider.hasActiveReservation)
                        const SizedBox(height: 14),
                    ],
                  ),
                ),
              ),

              if (!provider.hasActiveReservation)
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 120),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (ctx, i) {
                        final available = provider.slots
                            .where((s) => s.isAvailable)
                            .toList();
                        if (available.isEmpty) {
                          return Padding(
                            padding: const EdgeInsets.only(top: 40),
                            child: Center(
                              child: Column(
                                children: [
                                  const Icon(Icons.no_meeting_room_rounded,
                                      size: 52,
                                      color: AppColors.textMuted),
                                  const SizedBox(height: 12),
                                  Text('No slots available',
                                      style: AppTextStyles.headingSmall),
                                  Text('All slots are occupied or reserved.',
                                      style: AppTextStyles.bodyMedium),
                                ],
                              ),
                            ),
                          );
                        }
                        final slot = available[i];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: _AvailableSlotTile(slot: slot)
                              .animate(
                                  delay: Duration(
                                      milliseconds: 100 + i * 60))
                              .fadeIn(duration: 400.ms)
                              .slideX(begin: 0.1, end: 0),
                        );
                      },
                      childCount: provider.slots
                              .where((s) => s.isAvailable)
                              .isEmpty
                          ? 1
                          : provider.slots
                              .where((s) => s.isAvailable)
                              .length,
                    ),
                  ),
                ),

              if (provider.hasActiveReservation)
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 120),
                  sliver: SliverToBoxAdapter(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('All Slots',
                            style: AppTextStyles.headingMedium),
                        const SizedBox(height: 14),
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            mainAxisSpacing: 14,
                            crossAxisSpacing: 14,
                            childAspectRatio: 1.05,
                          ),
                          itemCount: provider.slots.length,
                          itemBuilder: (ctx, i) =>
                              SlotCard(slot: provider.slots[i]),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _ActiveReservationCard extends StatelessWidget {
  final ParkingProvider provider;

  const _ActiveReservationCard({required this.provider});

  String _formatDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final res = provider.activeReservation!;
    final remaining = res.remaining;
    final progress = remaining.inSeconds /
        (AppStrings.reservationMinutes * 60);

    final urgentColor = remaining.inMinutes < 3
        ? AppColors.occupied
        : remaining.inMinutes < 7
            ? AppColors.reserved
            : AppColors.primary;

    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                urgentColor.withOpacity(0.18),
                urgentColor.withOpacity(0.06),
              ],
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: urgentColor.withOpacity(0.4)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: urgentColor.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.bookmark_rounded,
                        color: urgentColor, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Active Reservation',
                            style: AppTextStyles.headingSmall),
                        Text('Slot ${res.slotNumber}',
                            style: AppTextStyles.bodyMedium),
                      ],
                    ),
                  ),
                  // Countdown
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: urgentColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      _formatDuration(remaining),
                      style: AppTextStyles.displayMedium
                          .copyWith(color: urgentColor, fontSize: 22),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Progress bar
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: progress.clamp(0.0, 1.0),
                  backgroundColor: AppColors.glassBase,
                  valueColor:
                      AlwaysStoppedAnimation<Color>(urgentColor),
                  minHeight: 6,
                ),
              ),
              const SizedBox(height: 6),
              Text('${remaining.inMinutes} min remaining',
                  style: AppTextStyles.bodySmall),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: provider.isLoading
                          ? null
                          : provider.cancelReservation,
                      icon: const Icon(Icons.cancel_outlined, size: 16),
                      label: const Text('Cancel'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.occupied,
                        side: BorderSide(
                            color: AppColors.occupied.withOpacity(0.5)),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        padding:
                            const EdgeInsets.symmetric(vertical: 12),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: provider.isLoading
                          ? null
                          : provider.confirmArrival,
                      icon: const Icon(Icons.directions_car_rounded,
                          size: 16),
                      label: const Text("I've Arrived"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.available,
                        padding:
                            const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AvailableSlotTile extends StatelessWidget {
  final ParkingSlot slot;

  const _AvailableSlotTile({required this.slot});

  @override
  Widget build(BuildContext context) {
    return Consumer<ParkingProvider>(
      builder: (ctx, provider, _) => GestureDetector(
        onTap: () async {
          if (provider.hasActiveReservation) {
            ScaffoldMessenger.of(ctx).showSnackBar(
              SnackBar(
                content: const Text('You already have an active reservation.'),
                backgroundColor: AppColors.bgCard,
                behavior: SnackBarBehavior.floating,
              ),
            );
            return;
          }
          _showConfirmDialog(ctx, provider);
        },
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.available.withOpacity(0.08),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                    color: AppColors.available.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: AppColors.available.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Text(
                        'P${slot.slotNumber}',
                        style: AppTextStyles.headingMedium
                            .copyWith(color: AppColors.available),
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Slot ${slot.slotNumber}',
                            style: AppTextStyles.headingSmall),
                        Text('Available — Tap to reserve',
                            style: AppTextStyles.bodyMedium.copyWith(
                                color: AppColors.available)),
                      ],
                    ),
                  ),
                  Icon(Icons.arrow_forward_ios_rounded,
                      size: 16, color: AppColors.textMuted),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showConfirmDialog(BuildContext context, ParkingProvider provider) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.bgCard,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Reserve Slot ${slot.slotNumber}?',
            style: AppTextStyles.headingMedium),
        content: Text(
          'You will have ${AppStrings.reservationMinutes} minutes to arrive. '
          'The reservation will auto-cancel if you don\'t arrive in time.',
          style: AppTextStyles.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel',
                style: AppTextStyles.bodyMedium
                    .copyWith(color: AppColors.textSecondary)),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              final err = await provider.reserveSlot(slot);
              if (err != null && context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(err),
                    backgroundColor: AppColors.error,
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              }
            },
            child: const Text('Confirm'),
          ),
        ],
      ),
    );
  }
}
